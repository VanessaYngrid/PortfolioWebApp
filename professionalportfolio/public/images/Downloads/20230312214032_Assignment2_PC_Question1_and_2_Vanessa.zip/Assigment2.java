/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assigment2;

import java.util.Scanner;

/**
 *
 * @author vanes
 */
public class Assigment2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // --------------------------------------------------------
        // Assignment 2
        // Written by: Vanessa Yngrid Chuquitaipe Vargas 2240396
        // For "Programming Concepts I" Section 87412 and 01212 - Winter 2023
        // --------------------------------------------------------
        
        System.out.println( "Welcome to my program!\n");
        
        
        //Question 1
        //The program is a password generator that will ask the user to insert a word and generate a coded password based on the inserted word. Each letter has a corresponding character
        
        System.out.println( "??????????????????????????????????");
        System.out.println( "        Password Generator        ");
        System.out.println( "??????????????????????????????????\n");
        
        Scanner input = new Scanner(System.in);
        
        while (true) //used the true condition to repeatedly ask the user for a new word until they enter "no"
        {
            System.out.println("Enter a word: ");
            String word = input.nextLine(); //To ask the user enter a word
            
            if(word.equalsIgnoreCase("no")) //If the user enter No, no or NO, the program will stop it and print the message below
            {
                System.out.println("\n\nThanks for using our program.");
                System.exit(0);
            }
       
        System.out.print("\nThe generated password for " + "\"" + word + "\"" + " is ");
        
        for (int i=0; i < word.length(); i++) //since position 0 until the length of the line. i++ to go to each character of the text
           {
              char c = word.charAt(i);  //method call that returns the character at position i in the string word and assigns the character at position i to the variable c
                if (c == 'a' || c == 'b' || c == 'c' || c == 'd')
                    System.out.print("#");
                else if(c == 'e' || c == 'f' || c == 'g' || c == 'h')
                    System.out.print("@");
                else if (c == 'i' || c == 'j' || c == 'k' || c == 'l')
                    System.out.print("?");
                else if (c == 'm' || c == 'n' || c == 'o' || c == 'p')
                    System.out.print("%");
                else if (c == 'q' || c == 'r' || c == 's' || c == 't')
                    System.out.print("&");
                else if (c == 'u' || c == 'v' || c == 'w' || c == 'x')
                    System.out.print("$");
                else if (c == 'y' || c == 'z')
                    System.out.print("!");
                else
                   System.out.print("*"); 
              
                  }
        
        System.out.println();
        System.out.println("\n========================================");
      
        } 
   
        
      
    }
    
}
