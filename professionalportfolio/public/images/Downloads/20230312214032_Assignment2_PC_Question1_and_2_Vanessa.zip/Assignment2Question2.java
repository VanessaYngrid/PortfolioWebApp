/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package assignment2question2;

import java.util.Scanner;

/**
 *
 * @author vanes
 */
public class Assignment2Question2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        // --------------------------------------------------------
        // Assignment 2
        // Written by: Vanessa Yngrid Chuquitaipe Vargas 2240396
        // For "Programming Concepts I" Section 87412 and 01212 - Winter 2023
        // --------------------------------------------------------
        
        //Question 2
        //The program will display a menu with 3 options to the user to draw a shape and calculate its perimeter based on user input
        
        System.out.println( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
        System.out.println( "          Welcome to Shape Generator Program          ");
        System.out.println( "XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n");
        System.out.println("Choose an item from the following list:");
        System.out.println("---------------------------------------\n1 - Square\n2 - Triangle\n3 - Quit\n---------------------------------------\n");
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.print("Please enter your choice: "); 
        int item = keyboard.nextInt(); //to ask the user enter his choice
            
        while (true)//used the true condition to repeatedly ask the user for a new word until they enter "no"
        {
           
            if (item==1) //if it's a square, continue to the body of if
            {
                System.out.println("\nYou have entered '" + item + "' for 'Square'.");
                System.out.println("Please enter the length of the side:");
                int length = keyboard.nextInt();
            
                    for (int row = 0; row < length; row++) //to draw the square using the 'X', '/' and '\'
                    {
                        for (int column = 0; column < length; column++) {
                            if (row == column)
                                System.out.print("\\"); // primary diagonal
                            else if (row + column == length - 1)
                                System.out.print("/"); // secondary diagonal
                            else
                                System.out.print("X"); // X character
            }
            
               System.out.println();
            
            }
              int perimeterSquare = length *4; //to calculate the perimeter of the square
              System.out.println("\nThe perimeter of the Square is " + perimeterSquare);
            
              System.out.println("\nThanks for using Shape Generator Program!");
              System.exit(0);
            }
           
            
            else if (item==2)
            {
                System.out.println("\nYou have entered '" + item + "' for 'Triangle'.");
                
                System.out.println("Please enter the length of the side:");
                int length = keyboard.nextInt();
            
                    for(int line=1; line<=length;line++)  //changing the line
                    {
			for(int geometricFigure=1;geometricFigure<=line;geometricFigure++) //to draw the triangle using the 'X'
                            System.out.print("X");
                            System.out.println();	
                    }
                  
                int perimeterTriangle = length *3; //to calculate the perimeter of the triangle
                System.out.println("\nThe perimeter of the Triangle is " + perimeterTriangle);
            
                System.out.println("\nThanks for using Shape Generator Program!");
                System.exit(0);
            }
        
            else if(item == 3) //to quit the program with a closing message
            {
                System.out.println("\nSee you next time!");
                System.exit(0);
            }
        
            else //when the user input a number different than 1, 2 or 3 and to ask them to input the correct choice
            {
                System.out.print("Invalid choice!!! Try again: ");
                item = keyboard.nextInt(); 
            }   
            
    
    }  
    
        
    
}
    
}
