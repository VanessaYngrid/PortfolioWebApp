/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagementsystem;

/**
 *
 * @author vanes
 */
public class BenchmarkingAndEfficiencyEvaluation {
    
    public static void main(String[] args) {
        
        LibraryManagementSystem libSystem1 = new LibraryManagementSystem();
        
        //int nBook = 1000;
        //int nBook = 50000;
        //int nBook = 100000;
        int nBook = 1000000;
        
        int nUser = 100;
        //int nUser = 5000;
        //int nUser = 10000;
        //int nUser = 100000;
        
        //Add Book
        long startTime = System.currentTimeMillis();

        for (int i = 0; i < nBook; i++) 
        {
            libSystem1.addBook(i,"","","","");
        }

        long endTime = System.currentTimeMillis();
        long executionTime = endTime - startTime;

        System.out.println("The execution time for addBook is: " + executionTime + " milliseconds");
    
        //Add User
        startTime = System.currentTimeMillis();

        for (int i = 0; i < nUser; i++) 
        {
            libSystem1.addUser(i,"");
        }

        endTime = System.currentTimeMillis();
        executionTime = endTime - startTime;

        System.out.println("The execution time for addUser is: " + executionTime + " milliseconds");
        
        //Check available books in the library
        startTime = System.currentTimeMillis();

        for (int i = 0; i < nBook; i++) 
        {
            libSystem1.listAvailableBooks();
        }

        endTime = System.currentTimeMillis();
        executionTime = endTime - startTime;

        System.out.println("The execution time for listAvailableBooks is: " + executionTime + " milliseconds");
        
        //List all users in the library
        startTime = System.currentTimeMillis();

        for (int i = 0; i < nUser; i++) 
        {
            libSystem1.listUsers();
        }

        endTime = System.currentTimeMillis();
        executionTime = endTime - startTime;

        System.out.println("The execution time for listUsers is: " + executionTime + " milliseconds");
        
        //Delete a book from the library
        startTime = System.currentTimeMillis();

        for (int i = 0; i < nBook; i++) 
        {
            libSystem1.deleteBook(i);
        }

        endTime = System.currentTimeMillis();
        executionTime = endTime - startTime;

        System.out.println("The execution time for deleteBook is: " + executionTime + " milliseconds");
        
        //Add Book
        for (int i = 0; i < nBook; i++) 
        {
            libSystem1.addBook(i,"","","","");
        }
        
        //Borrow a book from the library
        startTime = System.currentTimeMillis();

        for (int i = 0; i < nBook; i++) 
        {
            libSystem1.borrowBook(nUser, i);
        }

        endTime = System.currentTimeMillis();
        executionTime = endTime - startTime;

        System.out.println("The execution time for borrowBook is: " + executionTime + " milliseconds");
    
        //Return a book to the library
        startTime = System.currentTimeMillis();

        for (int i = 0; i < nBook; i++) 
        {
            libSystem1.returnBook();
        }

        endTime = System.currentTimeMillis();
        executionTime = endTime - startTime;

        System.out.println("The execution time for returnBook is: " + executionTime + " milliseconds");
        
        //Search for a book by ID
        int[] searchID = {1, 500, 1000};

        for (int bookId : searchID)
        {
            startTime = System.currentTimeMillis();
            
            libSystem1.searchBookById(bookId);
            
            endTime = System.currentTimeMillis();
            executionTime = endTime - startTime;
            
             System.out.println("The execution time for searchBookById is: " + executionTime + " milliseconds");
        }
      
        //Search for a book by title
        String[] searchTitles = {"Title1", "Title500", "Title1000"};
      
        for (String title : searchTitles) 
        {
            startTime = System.currentTimeMillis();
            
            libSystem1.searchBooksByTitle(title);
            
            endTime = System.currentTimeMillis();
            executionTime = endTime - startTime;

            System.out.println("Execution time for searchBooksByTitle is: " + executionTime + " milliseconds");
        }
   
        

                
    
    }
    
}
