/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagementsystem;

/**
 *
 * @author vanes
 */
public class LibraryManagementSystemDemo {
    
    public static void main(String[] args) {
        
        LibraryManagementSystem libSystem = new LibraryManagementSystem();
        
        //Test Case 1: Add book
        libSystem.addBook(4587, "Pride and Prejudice", "Jane Austen", "Spanish", "Romance");
        libSystem.addBook(6749, "The Hobbit", "J.R.R. Tolkien", "English", "Fantasy");
        libSystem.addBook(6483, "Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "English", "Fantasy");
        libSystem.addBook(2805, "The Da Vinci Code", "Dan Brown", "English", "Mystery");
        libSystem.addBook(4241, "Romeo and Juliet", "William Shakespeare", "French", "Romance");
        
        //Test Case 2: Add User
        libSystem.addUser(302935, "Vanessa Vargas");
        libSystem.addUser(365053, "Eric Wou");
        libSystem.addUser(354958, "Fiorella Olenka");
        libSystem.addUser(392352, "Leisy Katya");
        libSystem.addUser(343840, "Liam Wou");
       
        //Test Case 3: Check available books
        libSystem.listAvailableBooks();
        
        //Test Case 4: List all users
        libSystem.listUsers();
        
        //Test Case 5: Delete a book
        libSystem.deleteBook(2805);
        System.out.println();
        
        //Test Case 6: Borrow a book
        libSystem.borrowBook(354958, 4241);
        libSystem.borrowBook(365053, 6483);
        
        //Test Case 3: Check available books
        libSystem.listAvailableBooks();
        
        //Test Case 7: Return a book
        libSystem.returnBook();
        
        //Test Case 8: Search for a book by ID
        libSystem.searchBookById(4587);
        System.out.println();
        
        //Test Case 9: Search for a deleted book
        libSystem.searchBookById(2805);
        System.out.println();
        
        //Test Case 3: Check available books
        libSystem.listAvailableBooks();
        
        //Test Case 10: Search for a book by title
        libSystem.searchBooksByTitle("Romeo and Juliet");
        System.out.println();
        libSystem.searchBooksByTitle("Harry Potter and the Sorcerer's Stone");
        System.out.println();
        
        //Test Case 11: Search for a not existing book
        libSystem.searchBookById(3029);
    }
    
}
