/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package librarymanagementsystem;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

/**
 *
 * @author vanes
 */
public class LibraryManagementSystem {

    private Map<Integer, Book> booksMap;
    private Map<Integer, User> usersMap;
    private Queue<Book> bookQueue; //Queue: first-in, first-out data structure.
    
    public LibraryManagementSystem()
    {
        this.booksMap = new HashMap<>();
        this.usersMap = new HashMap<>();
        this.bookQueue = new LinkedList<>(); //It is ideal for queue operations because it is efficient for inserting and removing elements from both ends of a list.
    }
    
    //Add a book to the library
    public void addBook(int bookId, String title, String author, String language, String genre)
    {
        Book books = new Book (bookId, title, author, language, genre);
        booksMap.put(bookId,books);
    }
    
    //Add a user to the library
    public void addUser(int userId, String name)
    {
        User users = new User(userId, name);
        usersMap.put(userId, users);  
    }
    
    //Check available books in the library
    public void listAvailableBooks()
    {
        System.out.println("List of books:");
        
        //Iteration over the Book's Object in the usersMap
        for(Book books : booksMap.values()) // values() - Returns a collection consisting of the values in the map
        {
            System.out.println("ID: " + books.getBookId() + " - Title: " + books.getTitle() + " -Author: " + books.getAuthor() + " - Language: " + books.getLanguage() + " - Genre: " + books.getGenre());
        }
        
        System.out.println();
    }
    
    //List all users in the library
    public void listUsers()
    {
        System.out.println("List of users:");
        
        //Iteration over the User's Object in the usersMap
        for(User users : usersMap.values()) // values() - Returns a collection consisting of the values in the map
        {
            System.out.println("ID: " + users.getUserId() + " - Name: " + users.getName());
        }
        
        System.out.println();
    }
    
    //Delete a book from the library
    public void deleteBook(int bookId)
    {
        Book books = booksMap.remove(bookId);
        
        if(books != null)
            System.out.println("Book deleted: \nID:" + bookId + " - Title: " + books.getTitle() + " -Author: " + books.getAuthor() + " - Language: " + books.getLanguage() + " - Genre: " + books.getGenre());
        else
            System.out.println("Book not found: \nID" + bookId + " - Title: " + books.getTitle() + " -Author: " + books.getAuthor() + " - Language: " + books.getLanguage() + " - Genre: " + books.getGenre());
    }
    
    //Borrow a book from the library
    public void borrowBook (int userId, int bookId)
    {
        User users = usersMap.get(userId); //to retrieve a "users object" from the "usersMap" associated with the given "userId".
        Book books = booksMap.get(bookId); //to retrieve a "books object" from the "booksMap" associated with the given "bookId"
        
        System.out.println("Books borrowed: ");
        
        if (users != null && books != null)
        {
            bookQueue.offer(books); //Insert an element(book) into a bookQueue
            System.out.println("The userId: " + userId + " - Name: " + users.getName() + " borrowed the book, ID: " + bookId + " - Author: " + books.getTitle() + " - Language: " + books.getLanguage() + " - Genre: " + books.getGenre());
            booksMap.remove(bookId); //remove the book from the booksMap
        }
        else
        {
            System.out.println("Invalid! Verify the user ID or book ID");
        }
        
        System.out.println();
    }
    
    //Return a book to the library
    public void returnBook()
    {
        if( !bookQueue.isEmpty())
        {
            Book returnedBooks = bookQueue.poll(); //Retrieves and removes the head of this queue, or null if this queue is empty.
            System.out.println("Book returned: \nID:" + returnedBooks.getBookId() + " - Title: " + returnedBooks.getTitle()  + " - Author: " + returnedBooks.getAuthor() + " - Language: " + returnedBooks.getLanguage()  + " - Genre: " + returnedBooks.getGenre());
            booksMap.put(returnedBooks.getBookId(), returnedBooks);
        }
        else
        {
            System.out.println("There are not books to return");
        }
    }
    
    //Search for a book by ID
    public void searchBookById(int bookId)
    {
        Book books = booksMap.get(bookId);
        if(books != null)
            System.out.println("\nBook found \nID: " + bookId + " - Title: " + books.getTitle() + " -Author: " + books.getAuthor() + " - Language: " + books.getLanguage() + " - Genre: " + books.getGenre());
        else
            System.out.println("The book ID " + bookId + " was not found ");         
    }
    
    //Search for a book by title
    public void searchBooksByTitle(String titles) 
    {
        System.out.println("Book:");
        boolean found = false;

        for (Book books : booksMap.values()) 
        {
            if (books.getTitle().equals(titles)) 
            {
                System.out.println("Title: " + books.getTitle() + " was found.");
                found = true;
                break;
            }
        }

        if (!found) 
        {
            System.out.println("No books found by title: " + titles);
        }
    }
    
    
    
    
}
