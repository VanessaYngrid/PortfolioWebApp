/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagementsystem;

/**
 *
 * @author vanes
 */
public class ComplexityAnalysis {
    
    /*
        
                                            Time Complexity                                                         Space Complexity
    addBook                     O(1)- Constant, Adding an entry to the HashMap                      O(N)- The space required is proportional to the number of books in the system
    addUser                     O(1)- Constant, Adding an entry to the HashMap                      O(N)- The space required is proportional to the number of users in the system
    listAvailableBooks          O(N)- Linear, Iteration over the values in the HashMap              O(1)- Constant , space required for temporary variables
    listUsers                   O(N)- Linear, Iteration over the values in the HashMap              O(1)- Constant , space required for temporary variables
    deleteBook                  O(1)- Constant, Removing an element from the HashMap                O(N)- The space required is proportional to the number of books in the system
    borrowBook                  O(1)- Contant, Inserting an element into a bookQueue,               O(1)- Constant , space required for temporary variables
                                               and removing an entry from a HashMap
    returnBook                  O(1)- Constant, Retrieving and removing the head of a Queue,        O(1)- Constant , space required for temporary variables
                                                and inserting an entry into a HashMap                                                              
    searchBookById              O(1)- Constant, Retrieving a value from the HashMap                 O(1)- Constant , space required for temporary variables
    searchBookByTitle           O(N)- Linear, Iterating over the booksMap                           O(1)- Constant , space required for temporary variables
    
    
    
    
    */
    
}
