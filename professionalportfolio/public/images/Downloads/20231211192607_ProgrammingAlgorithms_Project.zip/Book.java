/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package librarymanagementsystem;

/**
 *
 * @author vanes
 */
public class Book {
    private int bookId;
    private String title;
    private String author;
    private String language;
    private String genre;
    

    public Book() 
    {
        bookId= 0;
        title= "";
        author= "";
        language= "";
        genre = "";
    }
    
    public Book(int bookId, String title, String author, String language, String genre) 
    {
        this.bookId= bookId;
        this.title = title;
        this.author = author;
        this.language = language;
        this.genre = genre;
    }

    public void setTitle(String title) 
    {
        this.title = title;
    }

    public void setAuthor(String author) 
    {
        this.author = author;
    }

    public void setLanguage(String language) 
    {
        this.language = language;
    }

    public void setBookId(int bookId) 
    {
        this.bookId = bookId;
    }

    public void setGenre(String genre) 
    {
        this.genre = genre;
    }

    public String getTitle() 
    {
        return title;
    }

    public String getAuthor() 
    {
        return author;
    }

    public String getLanguage() 
    {
        return language;
    }

    public int getBookId() 
    {
        return bookId;
    }

    public String getGenre() 
    {
        return genre;
    }
    
    
    
    
    
    
    
    
    
    
    
}
